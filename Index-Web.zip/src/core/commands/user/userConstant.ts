import UserType = User.UserType;

/**
 * 本地用户
 */
export const LOCAL_USER: UserType = {
  username: "local",
};
