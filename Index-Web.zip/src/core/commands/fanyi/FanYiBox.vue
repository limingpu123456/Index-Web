<template>
  <div>
    <iframe src="https://fanyi.baidu.com/" />
  </div>
</template>

<script setup lang="ts">
import { toRefs } from "vue";

// interface FanYiBoxProps {
//
// }
//
// const props = withDefaults(defineProps<FanYiBoxProps>(), {});
// const {} = toRefs(props);
</script>

<style scoped></style>
