<template>
  <div>
    <div>珍惜生活，远离 DDOS！</div>
    <div>
      网络安全学习网站：
      <a href="https://ceshiya.vercel.app/" target="_blank">
        https://ceshiya.vercel.app/
      </a>
    </div>
    <img
      width="200"
      style="margin: 8px 0"
      src="https://s1.ax1x.com/2022/07/19/j76SQU.png"
      alt="做个好人"
    />
  </div>
</template>

<script setup lang="ts"></script>

<style scoped></style>
